"""
niryo_stream.py — Device Camera MJPEG Stream Server
====================================================
Serves a live MJPEG stream from a local device camera (webcam or USB camera)
on http://0.0.0.0:5001/stream and exposes a /health endpoint consumed by
the Node.js backend and the Angular worker dashboard.

CAMERA SOURCE:  cv2.VideoCapture (local device, index-based)
ENDPOINTS:      /stream   — MJPEG multipart stream (unchanged from robot mode)
                /health   — JSON health/status (same schema as robot mode)

To switch cameras:  change CAMERA_INDEX below (0=built-in, 1=first USB, …)
To revert to Niryo: comment the device-camera section and uncomment the
                    "Legacy Niryo Camera Config" blocks below.
"""

import sys
import cv2
import time
import threading
import logging
import numpy as np
from flask import Flask, Response, jsonify
from flask_cors import CORS


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ACTIVE LOCAL DEVICE CAMERA SETTINGS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#
#   CAMERA_INDEX  0 = built-in webcam (laptop/PC)
#                 1 = first USB/external camera
#                 2 = second USB/external camera
#   FRAME_WIDTH / FRAME_HEIGHT — requested resolution (camera may cap it)
#   FPS           — target frame rate (camera driver caps actual rate)
#
CAMERA_INDEX  = 1       # DroidCam is typically index 1 on Windows (0 = built-in webcam)
FRAME_WIDTH   = 1280
FRAME_HEIGHT  = 720
FPS           = 30
PORT          = 5001
JPEG_QUALITY  = 80
FRAME_INTERVAL  = 1.0 / FPS
FRAME_STALE_SEC = 5       # mark stream stale if no new frame for N seconds
MAX_BACKOFF     = 30      # cap exponential reconnect backoff at 30 s

# On Windows we try backends in order: MSMF → DSHOW → ANY
# DSHOW raises C++ exceptions on some drivers; MSMF is more stable on Win10/11
_WIN_BACKENDS = [cv2.CAP_MSMF, cv2.CAP_DSHOW, cv2.CAP_ANY] if sys.platform == "win32" else [cv2.CAP_ANY]

# --- Legacy Niryo Camera Config (commented fallback) ---
# ROBOT_IP        = "10.10.10.10"
# CONNECT_TIMEOUT = 8      # seconds per connection attempt
# MAX_BACKOFF     = 60     # cap exponential backoff at 60 s
# ---


logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("device-stream")

# Silence werkzeug access-log spam (GET /health, GET /robot-health every 3 s)
logging.getLogger("werkzeug").setLevel(logging.ERROR)

app = Flask(__name__)
CORS(app)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SHARED STATE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

_lock               = threading.Lock()
_latest_frame       = None          # bytes | None
_frame_count        = 0
_start_time         = time.time()
_last_frame_time    = 0.0
_camera_ok          = False
_reconnect_attempts = 0

# --- Legacy Niryo state variables (commented fallback) ---
# _robot_connected    = False
# _pyniryo_available  = False
# ---


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# LEGACY NIRYO ROBOT CONNECTION  (commented fallback)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# try:
#     from pyniryo import NiryoRobot
#     _pyniryo_available = True
#     log.info("pyniryo available")
# except ImportError:
#     log.warning("pyniryo not installed — robot connection disabled")

# def _connect_robot():
#     """Try once to connect to Niryo robot. Returns robot instance or None."""
#     if not _pyniryo_available:
#         return None
#     try:
#         log.info(f"Connecting to robot at {ROBOT_IP}:6001 (timeout {CONNECT_TIMEOUT}s)…")
#         robot = NiryoRobot(ROBOT_IP)
#         log.info("Robot connected ✔")
#         return robot
#     except Exception as exc:
#         log.warning(f"Robot connection failed: {exc}")
#         return None

# def robot_camera_loop():
#     """
#     Legacy Niryo robot camera capture loop.
#     Replaced by device_camera_loop() — kept here as fallback reference.
#
#     Old robot capture settings:
#       robot.get_img_compressed()         — fetches JPEG bytes from ROS/TCP
#       NiryoRobot(ROBOT_IP)               — TCP connection to 10.10.10.10
#       np.frombuffer + cv2.imdecode       — decode compressed image
#       cv2.putText "NIRYO STREAM ACTIVE"  — overlay text
#     """
#     global _latest_frame, _frame_count, _last_frame_time
#     global _camera_ok, _reconnect_attempts
#     robot = None
#     backoff = 2.0
#     while True:
#         if robot is None:
#             robot = _connect_robot()
#             with _lock:
#                 _reconnect_attempts += 1
#                 _robot_connected = robot is not None
#             if robot is None:
#                 fallback = _make_fallback_frame(
#                     f"Robot disconnected — reconnecting in {int(backoff)}s…"
#                 )
#                 with _lock:
#                     _latest_frame = fallback
#                     _camera_ok = False
#                 log.info(f"Retry in {backoff:.0f}s (attempt #{_reconnect_attempts})")
#                 time.sleep(backoff)
#                 backoff = min(backoff * 2, MAX_BACKOFF)
#                 continue
#             backoff = 2.0
#         try:
#             img = robot.get_img_compressed()
#             if img is None:
#                 time.sleep(0.1)
#                 continue
#             np_arr = np.frombuffer(img, np.uint8)
#             frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
#             if frame is None:
#                 time.sleep(0.1)
#                 continue
#             cv2.putText(frame, "NIRYO STREAM ACTIVE", (20, 30),
#                         cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
#             _, buffer = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])
#             with _lock:
#                 _latest_frame = buffer.tobytes()
#                 _frame_count += 1
#                 _last_frame_time = time.time()
#                 _camera_ok = True
#         except Exception as exc:
#             log.warning(f"Robot frame error: {exc}")
#             with _lock:
#                 _camera_ok = False
#                 _robot_connected = False
#             robot = None
#         time.sleep(FRAME_INTERVAL)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# FALLBACK FRAME  (shown when camera is unavailable)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _make_fallback_frame(message="Camera unavailable — reconnecting..."):
    h, w = 360, 640
    frame = np.zeros((h, w, 3), dtype=np.uint8)
    frame[:] = (20, 26, 36)                          # dark slate background

    cv2.rectangle(frame, (2, 2), (w - 3, h - 3), (0, 80, 120), 1)

    cx, cy = w // 2, h // 2 - 30
    cv2.line(frame, (cx - 40, cy), (cx - 10, cy), (0, 120, 180), 2)
    cv2.line(frame, (cx + 10, cy), (cx + 40, cy), (0, 120, 180), 2)
    cv2.circle(frame, (cx, cy), 18, (0, 80, 120), 2)
    cv2.putText(frame, "!", (cx - 6, cy + 6),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 180, 255), 2)

    for i, line in enumerate(message.split(" — ")):
        y = cy + 50 + i * 24
        text_size = cv2.getTextSize(line, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)[0]
        x = (w - text_size[0]) // 2
        cv2.putText(frame, line, (x, y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (150, 170, 200), 1)

    ts = time.strftime("%H:%M:%S")
    cv2.putText(frame, ts, (10, h - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (80, 100, 120), 1)

    _, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 60])
    return buf.tobytes()


_FALLBACK_BYTES = _make_fallback_frame()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# DEVICE CAMERA  — open helper
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _open_device_camera():
    """
    Open the local device camera at CAMERA_INDEX.
    Tries each backend in _WIN_BACKENDS until one succeeds.
    Returns an opened cv2.VideoCapture, or None on failure.
    """
    cap = None
    for backend in _WIN_BACKENDS:
        backend_name = {cv2.CAP_MSMF: "MSMF", cv2.CAP_DSHOW: "DSHOW", cv2.CAP_ANY: "ANY"}.get(backend, str(backend))
        log.info(f"Opening device camera index={CAMERA_INDEX} via backend={backend_name}…")
        try:
            cap = cv2.VideoCapture(CAMERA_INDEX, backend)
        except Exception as exc:
            log.warning(f"Backend {backend_name} raised exception: {exc}")
            cap = None
        if cap is not None and cap.isOpened():
            log.info(f"Camera opened with backend={backend_name}")
            break
        if cap is not None:
            cap.release()
            cap = None
        log.warning(f"Backend {backend_name} failed, trying next…")

    if cap is None or not cap.isOpened():
        log.warning(
            f"cv2.VideoCapture({CAMERA_INDEX}) failed with all backends — "
            f"check that index {CAMERA_INDEX} is a valid camera"
        )
        return None

    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)
    cap.set(cv2.CAP_PROP_FPS,          FPS)
    # Minimise internal buffer to reduce latency
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    actual_w   = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    actual_h   = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    actual_fps = cap.get(cv2.CAP_PROP_FPS)
    log.info(f"Device camera opened ✔  {actual_w}×{actual_h} @ {actual_fps:.1f} fps")
    return cap


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# DEVICE CAMERA LOOP  (runs in daemon thread)
# Replaces the legacy robot_camera_loop above.
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def camera_loop():
    """
    Primary capture loop for the local device camera.

    Behaviour:
    - Opens cv2.VideoCapture at CAMERA_INDEX on start.
    - Reads frames continuously, JPEG-encodes them, stores in _latest_frame.
    - If a frame read fails, emits a fallback JPEG and attempts to reopen.
    - Backs off exponentially (up to MAX_BACKOFF s) when camera unavailable.
    - The MJPEG generator reads _latest_frame and streams it to clients.
    """
    global _latest_frame, _frame_count, _last_frame_time
    global _camera_ok, _reconnect_attempts

    cap = None
    backoff = 2.0

    while True:
        # ── open / reopen camera ─────────────────────────────────────
        if cap is None or not cap.isOpened():
            if cap is not None:
                cap.release()

            with _lock:
                _reconnect_attempts += 1

            cap = _open_device_camera()

            if cap is None:
                fallback = _make_fallback_frame(
                    f"Camera {CAMERA_INDEX} unavailable — retry in {int(backoff)}s"
                )
                with _lock:
                    _latest_frame = fallback
                    _camera_ok = False

                log.info(f"Retry in {backoff:.0f}s (attempt #{_reconnect_attempts})")
                time.sleep(backoff)
                backoff = min(backoff * 2, MAX_BACKOFF)
                continue

            backoff = 2.0   # reset on successful open

        # ── capture frame ────────────────────────────────────────────
        ok, frame = cap.read()

        if not ok or frame is None:
            log.warning(
                f"Device camera (index={CAMERA_INDEX}) frame read failed — reconnecting…"
            )
            with _lock:
                _camera_ok = False
                _latest_frame = _make_fallback_frame(
                    f"Camera {CAMERA_INDEX} — frame lost — reconnecting…"
                )
            cap.release()
            cap = None
            time.sleep(0.5)
            continue

        # ── annotate ────────────────────────────────────────────────
        cv2.putText(
            frame,
            f"DEVICE CAM {CAMERA_INDEX} | LIVE",
            (20, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (0, 255, 0),
            2,
            cv2.LINE_AA,
        )

        # ── encode and publish ───────────────────────────────────────
        _, buffer = cv2.imencode(
            ".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY]
        )

        with _lock:
            _latest_frame    = buffer.tobytes()
            _frame_count    += 1
            _last_frame_time = time.time()
            _camera_ok       = True

        time.sleep(FRAME_INTERVAL)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# MJPEG STREAM GENERATOR
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def generate_stream():
    """Yield MJPEG multipart frames; falls back to _FALLBACK_BYTES when no frame is ready."""
    while True:
        with _lock:
            frame = _latest_frame if _latest_frame is not None else _FALLBACK_BYTES

        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n\r\n" + frame + b"\r\n"
        )

        time.sleep(FRAME_INTERVAL)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ROUTES  (same endpoints — frontend / Node.js unchanged)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@app.route("/stream")
def stream():
    """Live MJPEG stream — same URL as before, consumed by AI pipeline + dashboard."""
    return Response(
        generate_stream(),
        mimetype="multipart/x-mixed-replace; boundary=frame",
    )


@app.route("/robot-health")
def robot_health():
    """
    Stub endpoint kept for Node.js backend compatibility.
    Returns a minimal JSON so server.js robot_status polling doesn't 404.
    In device-camera mode there is no robot arm — status is always offline.
    """
    return jsonify({"robot_connected": False, "status": "offline"})


@app.route("/health")
def health():
    """
    JSON health payload — same schema as robot-camera mode so Node.js /api/stream/health
    and the Angular worker dashboard require zero changes.

    robot_connected is always False in device-camera mode; the dashboard
    shows 'DISCONNECTED' for the robot arm panel which is correct.
    """
    now    = time.time()
    uptime = round(now - _start_time, 1)

    with _lock:
        camera_ok          = _camera_ok
        frame_count        = _frame_count
        reconnect_attempts = _reconnect_attempts
        last_frame_age     = (
            round(now - _last_frame_time, 1) if _last_frame_time else None
        )

    avg_fps      = round(frame_count / max(uptime, 1), 2)
    stream_stale = (last_frame_age is None) or (last_frame_age > FRAME_STALE_SEC)

    camera_status = (
        "ok"     if (camera_ok and not stream_stale) else
        "stale"  if (camera_ok and stream_stale)     else
        "offline"
    )

    return jsonify({
        # ── Active device camera fields ──────────────────────────────
        "status":             "ok" if (camera_ok and not stream_stale) else "degraded",
        "camera_index":       CAMERA_INDEX,
        "camera_connected":   camera_ok,
        "uptime_sec":         uptime,
        "frames_captured":    frame_count,
        "avg_fps":            avg_fps,
        "stream_stale":       stream_stale,
        "last_frame_age_sec": last_frame_age,
        "camera_status":      camera_status,
        "reconnect_attempts": reconnect_attempts,
        # ── Legacy Niryo compat fields (kept so frontend schema is unchanged) ──
        "robot_connected":    False,     # always False — device-camera mode
        "pyniryo_available":  False,
        "robot_ip":           None,      # no robot in device-camera mode
    })


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# START
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

if __name__ == "__main__":
    log.info(
        f"Device-camera stream server starting on http://0.0.0.0:{PORT}\n"
        f"  Camera index : {CAMERA_INDEX}\n"
        f"  Target res   : {FRAME_WIDTH}×{FRAME_HEIGHT} @ {FPS} fps\n"
        f"  JPEG quality : {JPEG_QUALITY}\n"
        f"  Endpoints    : /stream  /health"
    )

    t = threading.Thread(target=camera_loop, daemon=True)
    t.start()

    app.run(host="0.0.0.0", port=PORT, threaded=True)
